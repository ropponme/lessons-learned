# Lessons Learned Preset v1.0.0

Integrates lessons learned into your spec-driven development workflow.

## Companion Extension Required

⚠️ **This preset requires the [Lessons Learned Extension](https://github.com/ropponme/lessons-learned) to function properly.**

The extension provides the `/speckit.feedback` command that collects PR feedback.

## Quick Install (Recommended)

Install both the extension and preset together:

```bash
# From GitHub releases
specify extension add --from https://github.com/ropponme/lessons-learned/releases/download/v1.0.0/lessons-learned-extension-1.0.0.zip
specify preset add --from https://github.com/ropponme/lessons-learned/releases/download/v1.0.0/lessons-learned-preset-1.0.0.zip
```

Or use the install script:

```bash
curl -fsSL https://raw.githubusercontent.com/ropponme/lessons-learned/v1.0.0/install.sh | bash -s v1.0.0
```

## Preset Only Install

If you already have the extension installed:

```bash
specify preset add --from https://github.com/ropponme/lessons-learned/releases/download/v1.0.0/lessons-learned-preset-1.0.0.zip
```

## What This Preset Provides

This preset customizes core Spec Kit commands to incorporate lessons learned:

- **`/speckit.specify`** - Reviews past lessons when creating specifications
- **`/speckit.plan`** - Applies learned patterns during planning
- **`/speckit.implement`** - References relevant lessons during implementation

## How It Works

1. Use `/speckit.feedback` (from the extension) to collect PR feedback
2. Lessons are stored in `.specify/memory/lessons-learned/`
3. Modified commands automatically reference these lessons in future work

For more information, see the [main repository](https://github.com/ropponme/lessons-learned).
