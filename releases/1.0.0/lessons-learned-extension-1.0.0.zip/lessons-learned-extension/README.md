# Lessons Learned Extension v1.0.0

Collect PR feedback, extract insights, and add lessons learned to your project memory.

## Companion Preset

⚠️ **This extension works best with the [Lessons Learned Preset](https://github.com/ropponme/lessons-learned).**

The preset integrates lessons learned into core Spec Kit commands (specify, plan, implement).

## Quick Install (Recommended)

Install both the extension and preset together:

```bash
# From GitHub releases
specify extension add --from https://github.com/ropponme/lessons-learned/releases/download/v1.0.0/lessons-learned-extension-1.0.0.zip
specify preset add --from https://github.com/ropponme/lessons-learned/releases/download/v1.0.0/lessons-learned-preset-1.0.0.zip
```

Or use the install script:

```bash
curl -fsSL https://raw.githubusercontent.com/ropponme/lessons-learned/v1.0.0/install.sh | bash -s v1.0.0
```

## Extension Only Install

If you only want the feedback collection command:

```bash
specify extension add --from https://github.com/ropponme/lessons-learned/releases/download/v1.0.0/lessons-learned-extension-1.0.0.zip
```

## What This Extension Provides

- **Command**: `/speckit.feedback` (alias: `/speckit.lessons-learned.feedback`)
  - Collects PR review comments and discussions
  - Extracts actionable insights
  - Stores lessons in project memory for future reference

## Usage

After installation, run the feedback command on your PRs:

```bash
/speckit.feedback
```

The extension will gather feedback from your open PR and add it to `.specify/memory/lessons-learned/`.

For more information, see the [main repository](https://github.com/ropponme/lessons-learned).
